package Main;

public class BibleVerse {
    private String book;
    private int chapter;
    private int verse;
    private String text;

    public String getBook() {
        return book;
    }

    public int getChapter() {
        return chapter;
    }

    public int getVerse() {
        return verse;
    }

    public String getText() {
        return text;
    }
}
